using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    // Start is called before the first frame update
   
    Vector3 start_pos;
    Vector3 center = new Vector3(0, 0, 0);
    public float[] xyz_ball = new float[3];

    float radius = 5.0f;
    [SerializeField] GameObject triangles;
    float gravitation_variable;
    float velocity;
    float x;
    float y;
    float z;

   

    void Start()
    {
        xyz_ball[0] = gameObject.transform.position.x;
        xyz_ball[1] = gameObject.transform.position.y;
        xyz_ball[2] = gameObject.transform.position.z;
        
        gravitation_variable = 9.81f;
    }

    private void FixedUpdate()
    {
        xyz_ball[0] = gameObject.transform.position.x;
        xyz_ball[1] = gameObject.transform.position.y;
        xyz_ball[2] = gameObject.transform.position.z;
        start_pos = gameObject.transform.position;
        //Debug.Log("Position of the ball " + xyz_ball[0]+" " + xyz_ball[1]+" " + xyz_ball[2]);
        move();

    }
    // Update is called once per frame
    void Update()
    {
        center_to_plane(triangles.GetComponent<Triangles_Script>().vertex[5], triangles.GetComponent<Triangles_Script>().normalized_vectors_triangl[3]);
        
    }

    bool center_to_plane(Vector3 p1, Vector3 normal)
    {
        bool collided;
        //here we calculate the distance between the ball and the vertex
        Vector3 vector_cp = new Vector3 (p1.x - center.x, p1.y - center.y, p1.z - center.z);
        //calculating dot product
        float dot = (vector_cp.x * normal.x) + (vector_cp.y * normal.y) + (vector_cp.z * normal.z);
        float magnitude = triangles.GetComponent<Triangles_Script>().magnitude(normal);
        float distance = Mathf.Abs(dot) / magnitude;

        if(distance <= radius)
        {
            collided = true;
            Debug.Log("Collision happened");
            float y_y = plane_function_();
            //gameObject.transform.position = new Vector3(gameObject.transform.position.x, y_y, gameObject.transform.position.z);
            return collided;
        }
        return false;
        
    }


    float acceleration_calc()
    {
        float tan = Mathf.Rad2Deg*Mathf.Atan(gameObject.transform.position.y/ gameObject.transform.position.x);
        float acceleration = -gravitation_variable * Mathf.Sin(tan) ;
        return acceleration;
    }
    void move()
    {
        
        float acceleration_x = acceleration_calc();
        Vector3 velocity;
        velocity.x = acceleration_x * Time.fixedDeltaTime; 
        velocity.y = 0; 
        velocity.z = -acceleration_x * Time.deltaTime; 
        x = start_pos.x + velocity.x + (acceleration_x* Mathf.Pow(Time.fixedDeltaTime,2)*0.5f);
        y = plane_function_();
        z = start_pos.z + velocity.z + (-acceleration_x * Mathf.Pow(Time.fixedDeltaTime, 2)*0.5f);
        gameObject.transform.position = new Vector3(x, y, z);
    }

    float plane_function_()
    {
        float y = (24.08f - (0.43f * gameObject.transform.position.z)) / 0.902f;
        return y+radius;
    }

}
