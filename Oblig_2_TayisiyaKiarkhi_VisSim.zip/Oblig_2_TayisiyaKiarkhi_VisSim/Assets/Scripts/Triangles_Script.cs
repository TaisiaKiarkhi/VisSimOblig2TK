using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using System.Globalization;
using UnityEngine.UI;

public class Triangles_Script : MonoBehaviour
{
    // Start is called before the first frame update
    float[] x_y_z = new float[3];
    public List<float[]> index = new List<float[]>();
    public List<float> floats = new List<float>();
    public List<int> ints = new List<int>();
    Mesh triangles;

    public Vector3[] vertex = new Vector3[6];
    Vector2[] uv = new Vector2[6];
    int[] triangl_construction = new int[12];
    Vector3[,] triangle_index;
    [SerializeField] public Vector3[] normalized_vectors_triangl = new Vector3[4];
    


    [SerializeField] GameObject ball;
    float period = 0;
    float time_interval = 1.0f;
    [SerializeField] Text triangle;

    private void Awake()
    {
        read_files("/Vertex_Data.txt", 1);
        read_files("/Treiangles_data.txt", 2);

        //creating triangles

        create_triangles();
        triangle_index = new Vector3[4, 3]
   {
        {vertex[ints[0]], vertex[ints[1]],vertex[ints[2]]},
        {vertex[ints[6]], vertex[ints[7]],vertex[ints[8]] },
        {vertex[ints[12]], vertex[ints[13]],vertex[ints[14]]},
        {vertex[ints[18]], vertex[ints[19]],vertex[ints[20]] }
   };

    }
    void Start()
    {
     // reading from file
       for (int i = 0; i < 4; i++)
       {
           
           for (int j = 0; j < 3; j++)
           {
               normalized_vectors_triangl[i]=normals_of_the_triangles(triangle_index[i, j], triangle_index[i, j + 1], triangle_index[i, j + 2]);
               j += 3;
               
           }
       }
      //  normalized_vectors_triangl[0] = normals_of_the_triangles(vertex[0], vertex[1], vertex[2]);

    }
    private void FixedUpdate()
    {
        for (int i = 0; i < 4; i++)
        {
            int trian;
            for (int j = 0; j < 3; j++)
            {
                bool check = barys_coord(triangle_index[i, j], triangle_index[i, j + 1], triangle_index[i, j + 2]);
                j = 3;
                if (check == true)
                {
                    trian = i + 1;
                    triangle.text = trian.ToString();
                   // Debug.Log("Ball is inside the" + trian + " triangle");
                }
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (period > time_interval)
        {
            for (int i = 0; i < 4; i++)
            {
                int trian;
                for (int j = 0; j < 3; j++)
                {
                    bool check = barys_coord(triangle_index[i, j], triangle_index[i, j + 1], triangle_index[i, j + 2]);
                    j = 3;
                    if (check == true)
                    {
                        trian = i + 1;
                         Debug.Log("Ball is inside the" + trian + " triangle");
                    }
                }
            }
        }
               
        period+=Time.deltaTime;
        
    }

    void create_triangles()
    {
        triangles = new Mesh();
        GetComponent<MeshFilter>().mesh = triangles;

      

        vertex[0] = new Vector3(floats[0], floats[1], floats[2]); //it would be done by using a for loop
        vertex[1] = new Vector3(floats[3], floats[4], floats[5]);
        vertex[2] = new Vector3(floats[6], floats[7], floats[8]);
        vertex[3] = new Vector3(floats[9], floats[10], floats[11]);
        vertex[4] = new Vector3(floats[12], floats[13], floats[14]);
        vertex[5] = new Vector3(floats[15], floats[16], floats[17]);

        triangl_construction[0] = 0;
        triangl_construction[1] = 1;
        triangl_construction[2] = 2;
        triangl_construction[3] = 0;
        triangl_construction[4] = 2;
        triangl_construction[5] = 3;
        triangl_construction[6] = 3;
        triangl_construction[7] = 2;
        triangl_construction[8] = 4;
        triangl_construction[9] = 4;
        triangl_construction[10]= 2;
        triangl_construction[11]= 5;

        triangles.vertices = vertex;
        triangles.uv = uv;
        triangles.triangles = triangl_construction;


    }

    /********read files with vertex data and triangle indices******/
    void read_files(string file_path, int variable_code)
    {
        try
        {
            string File_Path = Application.dataPath + file_path;

            using (StreamReader reader = new StreamReader(File_Path))
            {
                string line;

                while ((line = reader.ReadLine()) != null)
                {
                   if(variable_code == 1)
                    {
                        string[] floats_s = line.Split(new char[] { ',', ' ' }, System.StringSplitOptions.RemoveEmptyEntries);

                        foreach (string float_str in floats_s)
                        {
                            if (float.TryParse(float_str, System.Globalization.NumberStyles.Float, CultureInfo.InvariantCulture, out float parse_f))
                            {
                                floats.Add(parse_f);
                            }
                            else
                            {
                                Debug.Log("Failed to parse");
                            }
                        }
                        foreach (float parsed_float in floats)
                        {
                            Debug.Log(parsed_float + " parsed");
                        }
                    }
                   else if(variable_code == 2)
                    {
                        string[] ints_s = line.Split(new char[] { ',', ' ' }, System.StringSplitOptions.RemoveEmptyEntries);

                        foreach (string int_str in ints_s)
                        {
                            if (int.TryParse(int_str, System.Globalization.NumberStyles.Integer, CultureInfo.InvariantCulture, out int parse_int))
                            {
                                ints.Add(parse_int);
                            }
                            else
                            {
                                Debug.Log("Failed to parse");
                            }
                        }
                        foreach (int parsed_ints in ints)
                        {
                            Debug.Log(parsed_ints + " parsed");
                        }
                    }
                }
            }
        }
        catch (IOException a)
        {
            Debug.Log("Failed to read" + a.Message);
        }
    }


   bool barys_coord(Vector3 P1, Vector3 P2, Vector3 P3) //pass the vertex array indecies here
    {
        Vector2 balls_position = new Vector3(ball.GetComponent<Ball>().xyz_ball[0],  ball.GetComponent<Ball>().xyz_ball[2]);
        Vector2 x_1 = new Vector2(P2.x - P1.x, P2.z - P1.z); 
        Vector2 x_2 = new Vector2(P3.x - P1.x, P3.z - P1.z);

       float areal_x = cross_product(x_1, x_2);

        Vector2 u_1 = new Vector2(P2.x-balls_position.x,   P2.z - balls_position.y);
        Vector2 u_2 = new Vector2(P3.x - balls_position.x, P3.z - balls_position.y);

        float areal_u = cross_product(u_1, u_2);

        Vector2 v_1 = new Vector2(P1.x - balls_position.x,  P1.z - balls_position.y);
        Vector2 v_2 = new Vector2(P3.x - balls_position.x,  P3.z - balls_position.y);
        float areal_v = cross_product(v_2, v_1);

        Vector2 w_1 = new Vector3(P1.x - balls_position.x,  P1.z - balls_position.y);
        Vector2 w_2 = new Vector3(P2.x - balls_position.x,  P2.z - balls_position.y);
        float areal_w = cross_product(w_1, w_2);

        float u = areal_u/areal_x;
        float v = areal_v/areal_x ;
        float w = areal_w/areal_x;
        float sum = u + v + w;
        
        //Debug.Log("Floats sum:" + sum);
        Debug.Log("Floats u v w:" + u+" " +v+" " + w);

        bool return_check = false;
       if( u <0 || v <0 || w < 0)
        {
            return_check = false;
        }

       else if(u >= 0 || v>=0 || w >= 0)
        {
            return_check = true;
        }
        return return_check;
    }

    float cross_product(Vector2 p1, Vector2 p2)
    {
        float result = (p1.x * p2.y) - (p1.y * p2.x);
        return result;
    }


    public float magnitude(Vector3 vex)
    {
        float result = Mathf.Sqrt(Mathf.Pow(vex.x, 2) + Mathf.Pow(vex.y, 2) + Mathf.Pow(vex.z, 2));
        Debug.Log("magnitude results: " + result);
        return result;
    }

    Vector3 normals_of_the_triangles(Vector3 ver1, Vector3 ver2, Vector3 ver3)
    {
        Debug.Log("xyz  " + ver1.x + "  " + ver1.y + "  " + ver1.z);
        Debug.Log("xyz  " + ver2.x + "  " + ver2.y + "  " + ver2.z);
        Debug.Log("xyz  " + ver3.x + "  " + ver3.y + "  " + ver3.z);
        Vector3 vector_12 = new Vector3(ver2.x - ver1.x, ver2.y - ver1.y, ver2.z - ver1.z);
        Vector3 vector_13 = new Vector3(ver3.x - ver1.x, ver3.y - ver1.y, ver3.z - ver1.z);

        float x= (vector_12.y*vector_13.z)-(vector_13.y*vector_12.z);
        float y= -((vector_12.x * vector_13.z) - (vector_13.x * vector_12.z));
        float z= (vector_12.x * vector_13.y) - (vector_13.x * vector_12.y);
        Debug.Log("z results: " + z);


        Vector3 normal_vector = new Vector3(x,y,z);
        Vector3 normalized_vector = new Vector3(normal_vector.x/magnitude(normal_vector), normal_vector.y/magnitude(normal_vector), normal_vector.z / magnitude(normal_vector));
        return normalized_vector;

    }
}
